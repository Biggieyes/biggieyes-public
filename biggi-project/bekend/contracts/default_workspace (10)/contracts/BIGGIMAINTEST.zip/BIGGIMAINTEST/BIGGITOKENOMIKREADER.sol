// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "@openzeppelin/contracts/token/ERC20/IERC20.sol";

interface IUniswapV2Pair {
    function token0() external view returns (address);
    function token1() external view returns (address);
    function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
    function totalSupply() external view returns (uint256);
}

interface IUniswapV2Router02 {
    function WETH() external view returns (address);
    function getAmountsOut(uint amountIn, address[] calldata path) external view returns (uint[] memory amounts);
}

interface IMultiCollectionDistributor {
    function totalReceived() external view returns (uint256);
    function pending(address recipient) external view returns (uint256);
    function collectionRewards() external view returns (address);
    function reserve() external view returns (address);
    function buybackAgent() external view returns (address);
    function treasury() external view returns (address);
    function communityCenter() external view returns (address);
}

interface IBuybackAgent {
    function nativeBalance() external view returns (uint256);
    function biggiBalance() external view returns (uint256);
    function totalNativeReceived() external view returns (uint256);
    function totalNativeSpent() external view returns (uint256);
    function totalBiggiAcquired() external view returns (uint256);
    function autoBuybackEnabled() external view returns (bool);
    function paused() external view returns (bool);
    function lastBuybackAt() external view returns (uint256);
    function router() external view returns (address);
    function wrappedNative() external view returns (address);
    function treasury() external view returns (address);
}

interface IReserveV4 {
    function waitingBiggi() external view returns (uint256);
    function dexRefillBiggi() external view returns (uint256);
    function maticBalance() external view returns (uint256);
}

interface ILiquidityManager {
    function keeper() external view returns (address);
}

interface ILiquidityVault {
    function whitelistedPairs(address lp) external view returns (bool);
    function lpBalanceOf(address lp) external view returns (uint256);
}

interface IDripDistributor {
    function availableTokens() external view returns (uint256);
    function totalTopUp() external view returns (uint256);
    function totalClaimed() external view returns (uint256);
    function totalNotified() external view returns (uint256);
    function tokensPerMint() external view returns (uint256);
    function dripLM() external view returns (address);
}

interface ITokenRewards {
    function rewardsCap() external view returns (uint256);
    function rewardsMinted() external view returns (uint256);
    function unitReward() external view returns (uint256);
    function blockWeight(uint256 idx) external view returns (uint8);
    function tokenAddress() external view returns (address);
}

contract BiggiTokenomikReader {
    struct CoreStatus {
        address token;
        address weth;
        address router;
        address pair;
        uint112 reserveNative;
        uint112 reserveBiggi;
        uint256 lpTotalSupply;
        uint256 biggiPerNative;   // getAmountsOut(1 native)
        uint256 nativePerBiggi;   // getAmountsOut(1 BIGGI)
    }

    struct DistributorStatus {
        address distributor;
        uint256 totalReceived;
        uint256 pendingBuyback;
        address collectionRewards;
        address reserve;
        address buybackAgent;
        address treasury;
        address communityCenter;
    }

    struct BuybackStatus {
        address buybackAgent;
        uint256 nativeBalance;
        uint256 biggiBalance;
        uint256 totalNativeReceived;
        uint256 totalNativeSpent;
        uint256 totalBiggiAcquired;
        bool autoBuybackEnabled;
        bool paused;
        uint256 lastBuybackAt;
        address router;
        address wrappedNative;
        address treasury;
    }

    struct ReserveStatus {
        address reserve;
        uint256 maticBalance;
        uint256 waitingBiggi;
        uint256 dexRefillBiggi;
        address liquidityManager;
        address keeper;
        address liquidityVault;
        bool pairWhitelisted;
        uint256 lpBalanceInVault;
    }

    struct DripStatus {
        address dripDistributor;
        uint256 availableTokens;
        uint256 totalTopUp;
        uint256 totalClaimed;
        uint256 totalNotified;
        uint256 tokensPerMint;
        address dripLM;
    }

    struct TokenRewardsStatus {
        address tokenRewards;
        uint256 rewardsCap;
        uint256 rewardsMinted;
        uint256 balance;
        uint256 unitReward;
        uint8[11] blockWeights;
        address token;
    }

    address public immutable TOKEN;
    address public immutable WETH;
    address public immutable ROUTER;
    address public immutable PAIR;
    address public immutable DISTRIBUTOR;
    address public immutable BUYBACK;
    address public immutable RESERVE;
    address public immutable LIQUIDITY_MANAGER;
    address public immutable LIQUIDITY_VAULT;
    address public immutable DRIP_DISTRIBUTOR;
    address public immutable TOKEN_REWARDS;

    constructor(
        address token_,
        address router_,
        address pair_,
        address distributor_,
        address buyback_,
        address reserve_,
        address lm_,
        address vault_,
        address dripDistributor_,
        address tokenRewards_
    ) {
        TOKEN = token_;
        ROUTER = router_;
        PAIR = pair_;
        DISTRIBUTOR = distributor_;
        BUYBACK = buyback_;
        RESERVE = reserve_;
        LIQUIDITY_MANAGER = lm_;
        LIQUIDITY_VAULT = vault_;
        DRIP_DISTRIBUTOR = dripDistributor_;
        TOKEN_REWARDS = tokenRewards_;
        WETH = IUniswapV2Router02(router_).WETH();
    }

    function getFullStatus() external view returns (
        CoreStatus memory core,
        DistributorStatus memory dist,
        BuybackStatus memory buy,
        ReserveStatus memory res,
        DripStatus memory drip,
        TokenRewardsStatus memory tr
    ) {
        core = _coreStatus();
        dist = _distributorStatus();
        buy = _buybackStatus();
        res = _reserveStatus();
        drip = _dripStatus();
        tr = _tokenRewardsStatus();
    }

    function _coreStatus() internal view returns (CoreStatus memory c) {
        c.token = TOKEN;
        c.router = ROUTER;
        c.pair = PAIR;
        c.weth = WETH;

        // reserves
        try IUniswapV2Pair(PAIR).getReserves() returns (uint112 r0, uint112 r1, uint32) {
            address t0 = IUniswapV2Pair(PAIR).token0();
            if (t0 == WETH) {
                c.reserveNative = r0;
                c.reserveBiggi = r1;
            } else {
                c.reserveNative = r1;
                c.reserveBiggi = r0;
            }
        } catch {}

        try IUniswapV2Pair(PAIR).totalSupply() returns (uint256 ts) { c.lpTotalSupply = ts; } catch {}

        // prices (simple getAmountsOut on router)
        address[] memory path = new address[](2);
        path[0] = WETH;
        path[1] = TOKEN;
        try IUniswapV2Router02(ROUTER).getAmountsOut(1e18, path) returns (uint[] memory amounts) {
            if (amounts.length > 1) c.biggiPerNative = amounts[1];
        } catch {}

        address[] memory path2 = new address[](2);
        path2[0] = TOKEN;
        path2[1] = WETH;
        try IUniswapV2Router02(ROUTER).getAmountsOut(1e18, path2) returns (uint[] memory amounts2) {
            if (amounts2.length > 1) c.nativePerBiggi = amounts2[1];
        } catch {}
    }

    function _distributorStatus() internal view returns (DistributorStatus memory d) {
        d.distributor = DISTRIBUTOR;
        IMultiCollectionDistributor mc = IMultiCollectionDistributor(DISTRIBUTOR);
        try mc.totalReceived() returns (uint256 trc) { d.totalReceived = trc; } catch {}
        try mc.pending(BUYBACK) returns (uint256 p) { d.pendingBuyback = p; } catch {}
        try mc.collectionRewards() returns (address a) { d.collectionRewards = a; } catch {}
        try mc.reserve() returns (address a2) { d.reserve = a2; } catch {}
        try mc.buybackAgent() returns (address a3) { d.buybackAgent = a3; } catch {}
        try mc.treasury() returns (address a4) { d.treasury = a4; } catch {}
        try mc.communityCenter() returns (address a5) { d.communityCenter = a5; } catch {}
    }

    function _buybackStatus() internal view returns (BuybackStatus memory b) {
        b.buybackAgent = BUYBACK;
        IBuybackAgent ba = IBuybackAgent(BUYBACK);
        try ba.nativeBalance() returns (uint256 v) { b.nativeBalance = v; } catch {}
        try ba.biggiBalance() returns (uint256 v2) { b.biggiBalance = v2; } catch {}
        try ba.totalNativeReceived() returns (uint256 v3) { b.totalNativeReceived = v3; } catch {}
        try ba.totalNativeSpent() returns (uint256 v4) { b.totalNativeSpent = v4; } catch {}
        try ba.totalBiggiAcquired() returns (uint256 v5) { b.totalBiggiAcquired = v5; } catch {}
        try ba.autoBuybackEnabled() returns (bool v6) { b.autoBuybackEnabled = v6; } catch {}
        try ba.paused() returns (bool v7) { b.paused = v7; } catch {}
        try ba.lastBuybackAt() returns (uint256 v8) { b.lastBuybackAt = v8; } catch {}
        try ba.router() returns (address r) { b.router = r; } catch {}
        try ba.wrappedNative() returns (address w) { b.wrappedNative = w; } catch {}
        try ba.treasury() returns (address t) { b.treasury = t; } catch {}
    }

    function _reserveStatus() internal view returns (ReserveStatus memory r) {
        r.reserve = RESERVE;
        r.liquidityManager = LIQUIDITY_MANAGER;
        r.liquidityVault = LIQUIDITY_VAULT;

        IReserveV4 res = IReserveV4(RESERVE);
        try res.maticBalance() returns (uint256 v) { r.maticBalance = v; } catch {}
        try res.waitingBiggi() returns (uint256 v2) { r.waitingBiggi = v2; } catch {}
        try res.dexRefillBiggi() returns (uint256 v3) { r.dexRefillBiggi = v3; } catch {}

        try ILiquidityManager(LIQUIDITY_MANAGER).keeper() returns (address k) { r.keeper = k; } catch {}
        try ILiquidityVault(LIQUIDITY_VAULT).whitelistedPairs(PAIR) returns (bool w) { r.pairWhitelisted = w; } catch {}
        try ILiquidityVault(LIQUIDITY_VAULT).lpBalanceOf(PAIR) returns (uint256 lp) { r.lpBalanceInVault = lp; } catch {}
    }

    function _dripStatus() internal view returns (DripStatus memory d) {
        d.dripDistributor = DRIP_DISTRIBUTOR;
        IDripDistributor dd = IDripDistributor(DRIP_DISTRIBUTOR);
        try dd.availableTokens() returns (uint256 v) { d.availableTokens = v; } catch {}
        try dd.totalTopUp() returns (uint256 v2) { d.totalTopUp = v2; } catch {}
        try dd.totalClaimed() returns (uint256 v3) { d.totalClaimed = v3; } catch {}
        try dd.totalNotified() returns (uint256 v4) { d.totalNotified = v4; } catch {}
        try dd.tokensPerMint() returns (uint256 v5) { d.tokensPerMint = v5; } catch {}
        try dd.dripLM() returns (address a) { d.dripLM = a; } catch {}
    }

    function _tokenRewardsStatus() internal view returns (TokenRewardsStatus memory t) {
        t.tokenRewards = TOKEN_REWARDS;
        ITokenRewards tr = ITokenRewards(TOKEN_REWARDS);
        try tr.rewardsCap() returns (uint256 v) { t.rewardsCap = v; } catch {}
        try tr.rewardsMinted() returns (uint256 v2) { t.rewardsMinted = v2; } catch {}
        try tr.unitReward() returns (uint256 v3) { t.unitReward = v3; } catch {}
        try tr.tokenAddress() returns (address a) { t.token = a; } catch { t.token = TOKEN; }
        try IERC20(t.token).balanceOf(TOKEN_REWARDS) returns (uint256 bal) { t.balance = bal; } catch {}
        for (uint256 i = 0; i < 11; i++) {
            try tr.blockWeight(i) returns (uint8 w) {
                t.blockWeights[i] = w;
            } catch {
                t.blockWeights[i] = 0;
            }
        }
    }
}
